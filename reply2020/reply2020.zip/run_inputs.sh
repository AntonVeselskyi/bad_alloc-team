for i in ./input/*.txt ;
do echo $i 
./solution $i;
#sed '$d' ${i}_res > tmp.txt
#mv tmp.txt ${i}_res 
done
