g++ -std=c++17 solution.cpp -o solution
